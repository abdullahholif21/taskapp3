    <!-- main section -->
    <section class="main">
        <!-- Navbar -->
        <nav>
            <div class="sidebar-button">
                <i role="button" class='fa-solid fa-bars sidebarBtn'></i>
                <span class="dashboard"><?php echo isset($pageTitle) ?  $pageTitle : 'Task app' ?></span>
            </div>
        </nav>