<?php
include_once('./config/auth.php');


logout();

?>