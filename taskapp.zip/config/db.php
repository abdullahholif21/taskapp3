<?php

 function getConnection(){
    try {
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $db = 'task_ms';
    return new mysqli($host, $user, $pass, $db);
    } catch (\Throwable $th) {
        echo $th->getMessage();
    }



}

?>