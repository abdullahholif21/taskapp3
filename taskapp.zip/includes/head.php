<?php include_once('./config/db.php');

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Bootcamp course</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!-- font awesome  CDN Link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <!-- bootstrap CDN link -->
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css" type="text/css">
    <link href="./assets/css/main.css" type="text/css" rel="stylesheet" />
</head>

<body>